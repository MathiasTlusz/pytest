from calc import soma

def test_soma():
    assert soma(2, 3) == 5

def test_soma_negativo():
    assert soma (-1, 1) == 0