from calc import calcular_preco

def test_sem_desconto():
    assert calcular_preco(100, 0) == 100.00


def test_com_desconto():
    assert calcular_preco(100, 10) == 90.00


def test_desconto_100():
    assert calcular_preco(100, 100) == 0.00


def test_valor_zero():
    assert calcular_preco(0, 50) == 0.00