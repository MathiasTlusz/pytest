from calc import calcular_idade

def test_idade_false():
    assert calcular_idade(17) == False

def test_idade_true():
    assert calcular_idade(19) == True

def test_idade_false_po():
    assert calcular_idade(18) == True

def test_idade_false_ze():
    assert calcular_idade(0) == False

def test_idade_false_ne():
    assert calcular_idade(-6) == False