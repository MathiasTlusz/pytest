def soma(a, b):
    return a + b

def calcular_preco(v, pd):
      return round(v * (1 - pd / 100), 2)

def calcular_idade(i):
     return i >= 18

def calcular_media(*notas):
    for nota in notas:
        if nota < 0 or nota > 10:
            return None
            
    return sum(notas) / len(notas)