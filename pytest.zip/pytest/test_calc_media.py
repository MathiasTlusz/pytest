from calc import calcular_media

def test_media_abaixo_6():
    assert calcular_media(4, 5) == 4.5

def test_media_igual_6():
    assert calcular_media(5, 7) == 6.0

def test_media_acima_6():
    assert calcular_media(8, 9, 10) == 9.0

def test_media_limite_0():
    assert calcular_media(0, 0) == 0.0

def test_media_limite_10():
    assert calcular_media(10, 10) == 10.0

def test_media_fora_intervalo():
    assert calcular_media(-1, 8) == None
    assert calcular_media(7, 11) == None